import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {Incident, incidents, cur_incident} from './incidentsarray.js';

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class NewIncident extends Component {

  constructor(props)  {
    super(props);
    
    this.state = {
      inc_type: "",
      pnum: "",
      email: "",
      date: "",
      loc: "",
      desc: "",
      name: "",
      status: "Open"
    };
    
    this.handleChange_name = this.handleChange_name.bind(this);
    this.handleChange_inc = this.handleChange_inc.bind(this);
    this.handleChange_pnum = this.handleChange_pnum.bind(this);
    this.handleChange_email = this.handleChange_email.bind(this);
    this.handleChange_date = this.handleChange_date.bind(this);
    this.handleChange_loc = this.handleChange_loc.bind(this);
    this.handleChange_desc = this.handleChange_desc.bind(this);

    this.changeSelected = this.changeSelected.bind(this);

    
  };

  handleChange_name(event)
  {
    this.setState({name: event.target.value});

  };

  handleChange_inc(event)
  {
    this.setState({inc_type: event.target.value});

  };

  handleChange_pnum(event)
  {
    this.setState({pnum: event.target.value});

  };

  handleChange_email(event)
  {
    this.setState({email: event.target.value});

  };

  handleChange_date(event)
  {
    this.setState({date: event.target.value});

  };

  handleChange_loc(event)
  {
    this.setState({loc: event.target.value});

  };

  handleChange_desc(event)
  {
    this.setState({desc: event.target.value});

  };


  changeSelected()  {
    incidents[cur_incident].setIncidentStates(this.state.inc_type, this.state.pnum, this.state.email, 
      this.state.date, this.state.loc, this.state.desc, this.state.name, this.state.status);

      this.props.changeRState(3)
  };

  

  

  render()  
  {

  return (
    <><p>
    <h5>
    Report Incident
    </h5>
    </p>
    
    <h6>
    <form>

    <label>Full Name: 
      <input type = "text" id = "type" value = {this.state.name} onChange = {this.handleChange_name} />
    </label>
    <br></br><br></br>
    <label>Incident Type: 
      <input type = "text" id = "type" value = {this.state.inc_type} onChange = {this.handleChange_inc} />
    </label>
    <br></br><br></br>
    <label>Phone Number: 
      <input type = "text1" id = "pnumber" value = {this.state.pnum} onChange = {this.handleChange_pnum} />
    </label>
    <br></br><br></br>
    <label>Email: 
      <input type = "text2" id = "per_email" value = {this.state.email} onChange = {this.handleChange_email} />
    </label>
    <br></br><br></br>
    <label>Date: 
      <input type = "text3" id = "senddate" value = {this.state.date} onChange = {this.handleChange_date} />
    </label>
    <br></br><br></br>
    <label>Location:
      <input type = "text4" id = "location" value = {this.state.loc} onChange = {this.handleChange_loc} />
    </label>
    <br></br><br></br>
    <label>Description: 
      <input type = "text5" id = "description" value = {this.state.desc} onChange = {this.handleChange_desc} />
    </label>
    
    </form>
    </h6>

    <p>
    <h6 class = "btn">
    <br></br>
    <br></br>
    <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => this.changeSelected()}>Save and Exit</button>
    </h6>
    </p>
    
    
    <h3>
    &copy; 2023 by Group 5
    </h3></>

  );
  }

}

export default NewIncident;
