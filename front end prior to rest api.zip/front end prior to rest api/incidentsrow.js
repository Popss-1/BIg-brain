import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {Incident, incidents, cur_incident} from './incidentsarray.js';

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';
import ShowIncidents from './incidentpage.js';



class IncidentRow extends Component {

  constructor(props, {indx})  
  {
    super(props)

    this.index = {indx}
  };

  render()
  {
   return (   
      <tr>
        <td>{incidents[index].state.desc}</td>
        <td>{incidents[index].state.full_name}</td>
        <td>{incidents[index].state.phone_number}</td>
        <td>{incidents[index].state.personal_email}</td>
        <td>{incidents[index].state.date_current}</td>
        <td>{incidents[index].state.loc}</td>
        <td>{incidents[index].state.status_type}</td>
        <td>{incidents[index].state.type_inc}</td>
        <td><button type = "button" onClick = {() => this.props.editFunction(index)}>Edit</button>
            <button type = "button" onClick = {() => this.props.detailsFunction(index)}>Details</button>
            <button type = "button" onClick = {() => this.props.deleteFunction(index)}>Delete</button></td>
      </tr>  
    );
   }

}

export default IncidentRow;