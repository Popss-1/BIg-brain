import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {Incident, incidents, cur_incident} from './incidentsarray.js';
import NewIncident from './newincident.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class DetailsIncident extends Component {

  constructor(props)  {
    super(props)

  };

  render()  
  {

  return (
    <><p>
      <h5>
        Incident: {incidents[cur_incident].state.desc} at {incidents[cur_incident].state.loc}
      </h5>
      <h4>
        Description: {incidents[cur_incident].state.desc}
      </h4>
      <br></br>
      <h4>
        <table>
          <tr>
            <th><i>Reporter Name</i></th>
            <th><i>Reporter Phone</i></th>
            <th><i>Reporter Email</i></th>
            <th><i>Incident Date</i></th>
            <th><i>Incident Location</i></th>
            <th><i>Incident Status</i></th>
            <th><i>Incident Type</i></th>
          </tr>
          <tr>
            <td>{incidents[cur_incident].state.full_name}</td>
            <td>{incidents[cur_incident].state.phone_number}</td>
            <td>{incidents[cur_incident].state.personal_email}</td>
            <td>{incidents[cur_incident].state.date_current}</td>
            <td>{incidents[cur_incident].state.loc}</td>
            <td>{incidents[cur_incident].state.status_type}</td>
            <td>{incidents[cur_incident].state.type_inc}</td>
          </tr>
        </table>
      </h4>
      <br></br>
      <h6 class = "btn2">
      <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => this.newIncident()}>Edit Incident</button>
      </h6>
      </p>
      <h3>
        &copy; 2023 by Group 5
      </h3></>

  );
  }

}

// maybe should have an edit button


export default DetailsIncident;
