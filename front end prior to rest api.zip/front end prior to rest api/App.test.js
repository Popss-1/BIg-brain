import { render, screen } from '@testing-library/react';
import App from './App';
import incidents from './App';
import ShowIncidents from './incidentpage.js';
import TemporaryComponent from './newincident.js';

test('render things', () => {
  
  render(<App />);

});
