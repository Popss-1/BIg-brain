package com.bigbrain.v1.DAOandRepositories;

import com.bigbrain.v1.models.Payments;

public interface PaymentDao {

    int save(Payments payment);

}
