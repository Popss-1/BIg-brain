package com.javatpoint.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//mark class as an Entity 
@Entity
//defining class name as Table name
@Table
public class Incidents
{
    //Defining book id as primary key
    @Id
    @Column
    private int incidentid;
    @Column
    private String incidentdescr;
    @Column
    private String incidentname;
    @Column
    private String reportername;
    @Column
    private String reporterphone;
    @Column
    private String reporteremail;
    @Column
    private String datereported;
    @Column
    private String incidentlocation;
    @Column
    private String incidentstatus;
    @Column
    private String inc_type;
    @Column
    private double inc_latitude;
    @Column
    private double inc_longitude;

    
    public int getincidentid() 
    {
        return incidentid;
    }

    public void setincidentid(int incidentid) 
    {
        this.incidentid = incidentid;
    }

    public String getincidentdescr()
    {
        return incidentdescr;
    }

    public void setincidentdescr(String incidentdescr) 
    {
        this.incidentdescr = incidentdescr;
    }

    public String getincidentname()
    {
        return incidentname;
    }

    public void setincidentname(String incidentname) 
    {
        this.incidentname = incidentname;
    }

    public String getreportername() 
    {
        return reportername;
    }

    public void setreportername(String reportername) 
    {
        this.reportername = reportername;
    }

    public String getreporterphone() 
    {
        return reporterphone;
    }

    public void setreporterphone(String reporterphone) 
    {
        this.reporterphone = reporterphone;
    }

    public String reporteremail() 
    {
        return reporteremail;
    }

    public void setreporteremail(String reporteremail) 
    {
        this.reporteremail = reporteremail;
    }

    public String getdatereported() 
    {
        return datereported;
    }

    public void setdatereported(String datereported) 
    {
        this.datereported = datereported;
    }

    public String getincidentlocation() 
    {
        return incidentlocation;
    }

    public void setincidentlocation(String incidentlocation) 
    {
        this.incidentlocation = incidentlocation;
    }

    public String getincidentstatus() 
    {
        return incidentstatus;
    }

    public void setincidentstatus(String incidentstatus) 
    {
        this.incidentstatus = incidentstatus;
    }

    public String getinc_type() 
    {
        return inc_type;
    }

    public void setinc_type(String inc_type) 
    {
        this.inc_type = inc_type;
    }

    public double getinc_latitude() 
    {
        return inc_latitude;
    }

    public void setinc_latitude(double inc_latitude) 
    {
        this.inc_latitude = inc_latitude;
    }

    public double getinc_longitude() 
    {
        return inc_longitude;
    }

    public void setinc_longitude(double inc_longitude) 
    {
        this.inc_longitude = inc_longitude;
    }
}