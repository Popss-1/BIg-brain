import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {Current_Incident, cur_incident} from './incidentclass.js';
import ShowIncidents from './incidentpage.js';
import NewIncident from './newincident';
import EditIncident from './editincident.js';
import DetailsIncident from './viewincident.js';
import IncidentMap from './incidentmap.js';
import MainPage from './mainpagecomp.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class App extends Component {

  constructor(props)  {
	  super(props)

	  this.changeRState = this.changeRState.bind(this);

    this.changelatlong = this.changelatlong.bind(this);

    this.state = {
      cur_lat: 0.0,
      cur_long: 0.0
    }
	};

	changeRState(new_num)  {
		state_switcher.changeState(new_num);
		//console.log(new_num);
		this.setState({});
	}

  changelatlong(latitude, longitude)
  {
    this.setState({ cur_lat: latitude, cur_long: longitude});

  }

	render()  
	{
  if (state_switcher.state.routing == 1)  { // Home Page
	 return(  
    <>
    <h1><i>Community Betterment Project</i></h1>
    <h2>
		<nav>
				<ul id="mainMenu">
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(1)}>Home</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(2)}>Users</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(3)}>Incidents</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(4)}>Requests</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(5)}>Messages</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(6)}>Payments</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(7)}>Incident Map</button></li>
				</ul>
		</nav>
		</h2>
    <MainPage />
    </>);
	}
  else if (state_switcher.state.routing == 3)  {  // Incidents Page
    return(
      <>
      <h1><i>Community Betterment Project</i></h1>
      <h2>
      <nav>
        <ul id="mainMenu">
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(1)}>Home</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(2)}>Users</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(3)}>Incidents</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(4)}>Requests</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(5)}>Messages</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(6)}>Payments</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(7)}>Incident Map</button></li>
				</ul>
      </nav>
      </h2>
      <ShowIncidents changeRState = {this.changeRState} />
      </>);

  }
  else if (state_switcher.state.routing == 7)  {  // Incidents Map Page
    return(
      <>
      <h1><i>Community Betterment Project</i></h1>
      <h2>
      <nav>
        <ul id="mainMenu">
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(1)}>Home</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(2)}>Users</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(3)}>Incidents</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(4)}>Requests</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(5)}>Messages</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(6)}>Payments</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(7)}>Incident Map</button></li>
				</ul>
      </nav>
      </h2>
      <IncidentMap changeRState = {this.changeRState} changelatlong = {this.changelatlong} />

      </>);

  }
  else if (state_switcher.state.routing == 8)  {  // Edit Incidents Page
    return(
      <>
      <h1><i>Community Betterment Project</i></h1>
      <h2>
      <nav>
        <ul id="mainMenu">
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(1)}>Home</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(2)}>Users</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(3)}>Incidents</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(4)}>Requests</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(5)}>Messages</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(6)}>Payments</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(7)}>Incident Map</button></li>
				</ul>
      </nav>
      </h2>
      <EditIncident changeRState = {this.changeRState} />
      </>);

  }
  else if (state_switcher.state.routing == 9)  {  // Details Incidents Page
	
    return(
      <>
      <h1><i>Community Betterment Project</i></h1>
      <h2>
      <nav>
        <ul id="mainMenu">
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(1)}>Home</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(2)}>Users</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(3)}>Incidents</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(4)}>Requests</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(5)}>Messages</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(6)}>Payments</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(7)}>Incident Map</button></li>
				</ul>
      </nav>
      </h2>
      <DetailsIncident changeRState = {this.changeRState} />
      </>);

  }
  else if (state_switcher.state.routing == 10)  {  // New Incidents Page
	
    return(
      <>
      <h1><i>Community Betterment Project</i></h1>
      <h2>
      <nav>
        <ul id="mainMenu">
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(1)}>Home</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(2)}>Users</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(3)}>Incidents</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(4)}>Requests</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(5)}>Messages</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(6)}>Payments</button></li>
					<li><button class="linkCss" title="hyperlink button" type="submit" onClick = {() => this.changeRState(7)}>Incident Map</button></li>
				</ul>
      </nav>
      </h2>
      <NewIncident changeRState = {this.changeRState} lat = {this.state.cur_lat} long = {this.state.cur_long} />
      </>);

  }

}
}

export default App;
