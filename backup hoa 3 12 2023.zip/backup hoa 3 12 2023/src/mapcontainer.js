import logo from './logo.svg';
import './App.css';
import React, { Component , useState, useEffect } from "react";
import {Current_Incident, cur_incident} from './incidentclass.js';
//import NewIncident from './newincident.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';
import { Map, Marker, InfoWindow } from 'google-maps-react';

const mapStyles = {
  width: '500px',
  height: '500px',
  marginLeft: '175px'
};

class MapContainer extends Component {
  
  constructor(props) {

    super(props);

    this.state = {
      data: [],
      activeMarker: null,
      showingInfoWindow: false,
      selectedPlace: {}
    };
  }

  componentDidMount() {
    fetch('http://localhost:8090/incident')
      .then(response => response.json())
      .then(data => {
        this.setState({ data });
      });
  }

  onMarkerClick = (props, marker) =>
    this.setState({
      activeMarker: marker,
      showingInfoWindow: true,
      selectedPlace: props
    });

  onMapClick = () => {
    if (this.state.showingInfoWindow) {
      this.setState({
        activeMarker: null,
        showingInfoWindow: false,
        selectedPlace: {}
      });
    } // else new incident
  };

  onMapDoubleClick = (mapProps, map, clickEvent) => {
    const latitude = clickEvent.latLng.lat();
    const longitude = clickEvent.latLng.lng();

    console.log("latitude from dblclick: " + latitude);
    console.log("longitude from dblclick: " + longitude);

    //cur_incident.setLatitude(latitude);
    //cur_incident.setLongitude(longitude);
    
    console.log("double click event");

    this.props.changelatlong(latitude, longitude);
    
    this.props.changeRState(10);

    
  };

  render() {
    return (
      <Map
        google={this.props.google}
        zoom={14}
        style={mapStyles}
        initialCenter={{ lat: 37.7749, lng: -122.4194 }}
        onClick={this.onMapClick}
        onDblclick={this.onMapDoubleClick}
        >

      {this.state.data.map(row => (
        <Marker
          key={row.incidentid}
          title={row.incidentname}
          position={{ lat: row.inc_latitude, lng: row.inc_longitude }}
          onClick={this.onMarkerClick}
          description={row.incidentdescr}
          reporter={row.reportername}
          location={row.incidentlocation}
        />
      ))}

      <InfoWindow
        marker={this.state.activeMarker}
        visible={this.state.showingInfoWindow}
      >
        <div>
          <h1 class="infowindow">Title: {this.state.selectedPlace.title}</h1>
          <h1 class="infowindow">Description: {this.state.selectedPlace.description}</h1>
          <h1 class="infowindow">Reported by: {this.state.selectedPlace.reporter}</h1>
          <h1 class="infowindow">Location: {this.state.selectedPlace.location}</h1>
        </div>
      </InfoWindow>
  </Map>
    );
  }
}

export default MapContainer;