import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {Current_Incident, cur_incident} from './incidentclass.js';

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class NewIncident extends Component {

  constructor(props) {
    super(props);

    this.state = {
      incidentid: 0,
      incidentdescr: "",
      incidentname: "",
      reportername: "",
      reporterphone: "",
      reporteremail: "",
      datereported: "",
      incidentlocation: "",
      incidentstatus: "",
      inc_type: "",
      loading: false,
      error: null
    };

    //this.handleChange = this.handleChange.bind(this);
    //this.changeSelected = this.changeSelected.bind(this);

  };


  componentDidMount() {
    this.setState({ loading: true });

    console.log("before loading latitude: " + this.props.lat);
    console.log("before loading longitude: " + this.props.long);

    const randomInteger = Math.floor(Math.random() * 100);

    this.state = { incidentid: randomInteger }

  }
  
  handleChange_name = (event) =>
  {
    this.setState({incidentname: event.target.value});

    console.log("incident name:" + this.state.incidentname);

  };

  handleChange_type = (event) =>
  {
    this.setState({inc_type: event.target.value});

  };
  
  handleChange_desc = (event) =>
  {
    this.setState({incidentdescr: event.target.value});

  };

  handleChange_repname = (event) =>
  {
    this.setState({reportername: event.target.value});

  };

  handleChange_pnum = (event) =>
  {
    this.setState({reporterphone: event.target.value});

  };

  handleChange_email = (event) =>
  {
    this.setState({reporteremail: event.target.value});

  };

  handleChange_date = (event) =>
  {
    this.setState({datereported: event.target.value});

  };

  handleChange_loc = (event) =>
  {
    this.setState({incidentlocation: event.target.value});

  };

  handleChange_status = (event) =>
  {
    this.setState({incidentstatus: event.target.value});

  };


  changeSelected = () => 
  {
    fetch('http://localhost:8090/incidents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        incidentid: this.state.incidentid,
        incidentdescr: this.state.incidentdescr,
        incidentname: this.state.incidentname,
        reportername: this.state.reportername,
        reporterphone: this.state.reporterphone,
        reporteremail: this.state.reporteremail,
        datereported: this.state.datereported,
        incidentlocation: this.state.incidentlocation,
        incidentstatus: this.state.incidentstatus,
        inc_type: this.state.inc_type,
        inc_latitude: this.props.lat,
        inc_longitude: this.props.long})
    })
      .then(response => response.json())
      .then(data => console.log(data))
      .catch(error => console.error(error));

  };


  handleChange = () =>
  {

    this.changeSelected();

    this.props.changeRState(7);
  
  }

  render()  
  {
    

  return (
    <><p>
    <h5>
    Report Incident
    </h5>
    <br></br>
    </p>
    
    <h6>
    <form>
    
    <label>Incident Name:
      <input type = "text9" id = "name2" value = {this.state.incidentname} onChange = {this.handleChange_name} />
    </label>
    <br></br><br></br>
    <label>Incident Type: 
      <input type = "text10" id = "type2" value = {this.state.inc_type} onChange = {this.handleChange_type} />
    </label>
    <br></br><br></br>
    <label>Description: 
      <input type = "text11" id = "description2" value = {this.state.incidentdescr} onChange = {this.handleChange_desc} />
    </label>
    <br></br><br></br>
    <label>Reporter Name: 
      <input type = "text12" id = "repname2" value = {this.state.reportername} onChange = {this.handleChange_repname} />
    </label>
    <br></br><br></br>
    <label>Phone Number: 
      <input type = "text13" id = "repphone2" value = {this.state.reporterphone} onChange = {this.handleChange_pnum} />
    </label>
    <br></br><br></br>
    <label>Email:
      <input type = "text14" id = "repemail2" value = {this.state.reporteremail} onChange = {this.handleChange_email} />
    </label>
    <br></br><br></br>
    <label>Date Reported: 
      <input type = "text15" id = "date2" value = {this.state.datereported} onChange = {this.handleChange_date} />
    </label>
    <br></br><br></br>
    <label>Location: 
      <input type = "text16" id = "location2" value = {this.state.incidentlocation} onChange = {this.handleChange_loc} />
    </label>
    <br></br><br></br>
    <label>Status: 
      <input type = "text17" id = "status2" value = {this.state.incidentstatus} onChange = {this.handleChange_status} />
    </label>

    </form>
    </h6>

    <p>
    <h6 class = "btn">
    <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => this.handleChange()}>Save and Exit</button>
    <br></br>
    <br></br>
    </h6>
    </p>
    
    
    <h3>
    &copy; 2023 by Group 5
    </h3></>

  );
  }

}

export default NewIncident;