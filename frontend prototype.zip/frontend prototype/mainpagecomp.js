import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";

import image1 from './picturehouses4.jpg';


class MainPage extends Component {

    render()  
    {
  
    return (
        <div>
        
        <img src={image1} alt="picture suburban" height="466" width="1024"/>
        <p>
        <h4>
        Welcome <b>nguyenhien123</b>!
        <br></br>
        <br></br>
        This is a webapp that helps the community stay connected by reporting incidents and streamlining the communication process.
        </h4>
        
        </p>

        <h3>
        &copy; 2023 by Group 5
        </h3>
        </div>
    );
    }
  
  }

export default MainPage;