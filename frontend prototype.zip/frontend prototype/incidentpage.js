import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {Incident, incidents, cur_incident} from './incidentsarray.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class ShowIncidents extends Component {

  constructor(props)  {
    super(props)

    this.editFunction = this.editFunction.bind(this);
    this.detailsFunction = this.detailsFunction.bind(this);
    this.deleteFunction = this.deleteFunction.bind(this);

  };

  editFunction(num)  
  {
   incidents[num].editIncidentPage(num);
   this.props.changeRState(8);

  };

  detailsFunction(num)  
  {
   incidents[num].editIncidentPage(num);
   this.props.changeRState(9);

  };

  deleteFunction(num)  
  {
   incidents.splice(num, 1);
   this.props.changeRState(3);

  };

  render()  
  {
    let items = []
      for (let i = 0; i < incidents.length; i++)  {
        items.push(IncidentRow(i))
     }

  return (
    <><p>
      <h5>
        Incidents
      </h5>
      <h4>
        <table>
          <tr>
            <th><i>Description</i></th>
            <th><i>Reporter Name</i></th>
            <th><i>Reporter Phone</i></th>
            <th><i>Reporter Email</i></th>
            <th><i>Incident Date</i></th>
            <th><i>Incident Location</i></th>
            <th><i>Incident Status</i></th>
            <th><i>Incident Type</i></th>
            <th></th>
          </tr>
          <>
          {items}
          </>
        </table>
      </h4>
      </p>
      <h3>
        &copy; 2023 by Group 5
      </h3></>

  );
  }

}


function IncidentRow(indx) {

   return (   
      <tr>
        <td>{incidents[indx].state.desc}</td>
        <td>{incidents[indx].state.full_name}</td>
        <td>{incidents[indx].state.phone_number}</td>
        <td>{incidents[indx].state.personal_email}</td>
        <td>{incidents[indx].state.date_current}</td>
        <td>{incidents[indx].state.loc}</td>
        <td>{incidents[indx].state.status_type}</td>
        <td>{incidents[indx].state.type_inc}</td>
        <td><button type = "button" >Edit</button>
            <button type = "button">Details</button>
            <button type = "button">Delete</button></td>
      </tr>  
    );

}


export default ShowIncidents;
