package com.javatpoint.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.javatpoint.model.Incidents;
import com.javatpoint.repository.IncidentsRepository;
//defining the business logic
@Service
public class IncidentsService 
{

@Autowired
IncidentsRepository incidentsRepository;
//getting all incidents record by using the method findaAll() of CrudRepository
public List<Incidents> getAllIncidents() 
{
    List<Incidents> incidents = new ArrayList<Incidents>();
    incidentsRepository.findAll().forEach(incidents1 -> incidents.add(incidents1));
    return incidents;
}

//getting a specific record by using the method findById() of CrudRepository
public Incidents getIncidentsById(int id) 
{
    return incidentsRepository.findById(id).get();
}

//saving a specific record by using the method save() of CrudRepository
public void saveOrUpdate(Incidents incidents) 
{
    incidentsRepository.save(incidents);
}

//deleting a specific record by using the method deleteById() of CrudRepository
public void delete(int id) 
{
    incidentsRepository.deleteById(id);
}

//updating a record
public void update(Incidents incidents, int incidentid) 
{
    incidentsRepository.save(incidents);
}
}