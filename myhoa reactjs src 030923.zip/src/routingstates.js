import './App.css';
import React, { Component } from "react";


class RoutingStates  {

    constructor()  {
    
        this.state = {
          routing: 1
        };
    
        this.changeState = this.changeState.bind(this);
      
      };

      changeState(routing_state)  {
        this.state = {routing: routing_state};
        //console.log(this.state.routing);
	  };


}

export const state_switcher = new RoutingStates();

export default RoutingStates;