import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {Current_Incident, cur_incident} from './incidentclass.js';

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class EditIncident extends Component {

  constructor(props) {
    super(props);

    this.state = {
      data: [],
      incidentid: "",
      incidentdescr: "",
      incidentname: "",
      reportername: "",
      reporterphone: "",
      reporteremail: "",
      datereported: "",
      incidentlocation: "",
      incidentstatus: "",
      inc_type: "",
      loading: false,
      error: null
    };

  };


  componentDidMount() {
    this.setState({ loading: true });

    fetch(`http://localhost:8090/incident/${cur_incident.state.current}`)
      .then(response => response.json())
      .then(data => this.setState({ data, incidentid: data.incidentid, incidentdescr: data.incidentdescr, incidentname: data.incidentname, 
        reportername: data.reportername, reporterphone: data.reporterphone, reporteremail: data.reporteremail, datereported: data.datereported,
        incidentlocation: data.incidentlocation, incidentstatus: data.incidentstatus, inc_type: data.inc_type }))
      .catch(error => this.setState({ error, loading: false }));
  }

  handleChange_name = (event) =>
  {
    this.setState({incidentname: event.target.value});

  };

  handleChange_type = (event) =>
  {
    this.setState({inc_type: event.target.value});

  };
  
  handleChange_desc = (event) =>
  {
    this.setState({incidentdescr: event.target.value});

  };

  handleChange_repname = (event) =>
  {
    this.setState({reportername: event.target.value});

  };

  handleChange_pnum = (event) =>
  {
    this.setState({reporterphone: event.target.value});

  };

  handleChange_email = (event) =>
  {
    this.setState({reporteremail: event.target.value});

  };

  handleChange_date = (event) =>
  {
    this.setState({datereported: event.target.value});

  };

  handleChange_loc = (event) =>
  {
    this.setState({incidentlocation: event.target.value});

  };

  handleChange_status = (event) =>
  {
    this.setState({incidentstatus: event.target.value});

  };


  changeSelected = () =>  
  {

    fetch('http://localhost:8090/incidents', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      incidentid: this.state.incidentid,
      incidentdescr: this.state.incidentdescr,
      incidentname: this.state.incidentname,
      reportername: this.state.reportername,
      reporterphone: this.state.reporterphone,
      reporteremail: this.state.reporteremail,
      datereported: this.state.datereported,
      incidentlocation: this.state.incidentlocation,
      incidentstatus: this.state.incidentstatus,
      inc_type: this.state.inc_type})
  })
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error(error));

  };


  handleChange = () =>  
  {

    this.changeSelected();

    this.props.changeRState(3);
  
  }

  render()  
  {

  const { data, loading, error } = this.state;
    

  return (
    <><p>
    <h5>
    Edit Incident
    </h5>
    </p>
    
    <h6>
    <form>
    
    <label>Incident Name:
      <input type = "text" id = "name" value = {this.state.incidentname} onChange = {this.handleChange_name} />
    </label>
    <br></br><br></br>
    <label>Incident Type: 
      <input type = "text1" id = "type" value = {this.state.inc_type} onChange = {this.handleChange_type} />
    </label>
    <br></br><br></br>
    <label>Description: 
      <input type = "text2" id = "description" value = {this.state.incidentdescr} onChange = {this.handleChange_desc} />
    </label>
    <br></br><br></br>
    <label>Reporter Name: 
      <input type = "text3" id = "repname" value = {this.state.reportername} onChange = {this.handleChange_repname} />
    </label>
    <br></br><br></br>
    <label>Phone Number: 
      <input type = "text4" id = "repphone" value = {this.state.reporterphone} onChange = {this.handleChange_pnum} />
    </label>
    <br></br><br></br>
    <label>Email:
      <input type = "text5" id = "repemail" value = {this.state.reporteremail} onChange = {this.handleChange_email} />
    </label>
    <br></br><br></br>
    <label>Date Reported: 
      <input type = "text6" id = "date" value = {this.state.datereported} onChange = {this.handleChange_date} />
    </label>
    <br></br><br></br>
    <label>Location: 
      <input type = "text7" id = "location" value = {this.state.incidentlocation} onChange = {this.handleChange_loc} />
    </label>
    <br></br><br></br>
    <label>Status: 
      <input type = "text8" id = "status" value = {this.state.incidentstatus} onChange = {this.handleChange_status} />
    </label>

    </form>
    </h6>

    <p>
    <h6 class = "btn">
    <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => this.handleChange()}>Save and Exit</button>
    <br></br>
    <br></br>
    </h6>
    </p>
    
    
    <h3>
    &copy; 2023 by Group 5
    </h3></>

  );
  }

}

export default EditIncident;
