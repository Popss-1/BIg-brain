import './App.css';
import React, { Component } from "react";
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';


class CompNavBar extends Component {

	constructor(props)  {
	  super(props)

	  this.changeRState = this.changeRState.bind(this);
	};

	changeRState(new_num)  {
		state_switcher.changeState(new_num);
		//console.log(new_num);
		this.setState({});
	}

	render()  
	{
	 return(
	    <h2>
		<nav>
				<ul id="mainMenu">
					<li><button type = "button" onClick = {() => this.changeRState(1)}>Home</button></li>
					<li><button type = "button" onClick = {() => this.changeRState(2)}>Users</button></li>
					<li><button type = "button" onClick = {() => this.changeRState(3)}>Incidents</button></li>
					<li><button type = "button" onClick = {() => this.changeRState(4)}>Requests</button></li>
					<li><button type = "button" onClick = {() => this.changeRState(5)}>Messages</button></li>
					<li><button type = "button" onClick = {() => this.changeRState(6)}>Payments</button></li>
					<li><button type = "button" onClick = {() => this.changeRState(7)}>Incident Map</button></li>
				</ul>
		</nav>
		</h2>);
	}
  
  }
  
  export default CompNavBar;





