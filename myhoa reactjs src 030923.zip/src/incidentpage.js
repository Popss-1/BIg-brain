import logo from './logo.svg';
import './App.css';
import React, { Component , useState, useEffect } from "react";
import {Current_Incident, cur_incident} from './incidentclass.js';
//import NewIncident from './newincident.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class ShowIncidents extends Component {

  constructor(props)  {
    super(props)

  };

  /*
  async componentDidMount() {
    const response = await fetch('localhost:8090/incident');
    //const body = await response.json();
    this.setState({});//users: body});
  }*/

  render()  
  {

  return (
    < DisplayRows changeRState = {this.props.changeRState} />
  );
  }

}

const DisplayRows = props => {

  const [data, setData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await fetch('http://localhost:8090/incident');
      const data = await response.json();
      setData(data);
    }
    fetchData();
  }, []);


  const newIncident = () =>  {
    console.log('new incident');

  };

  const incidentDetails = (id) =>  {
    cur_incident.setCurrentIncident(id);
    console.log("details button clicked " + id);
    props.changeRState(9);

  };


  const editFunction = (id) =>  { 
   cur_incident.setCurrentIncident(id);
   console.log("edit button clicked " + id);
   props.changeRState(8);

  };

  const deleteRow = async (id) => {
    // make an API call to delete the row
    await fetch(`http://localhost:8090/incident/${id}`, {
      method: 'DELETE',
    });

    // remove the deleted row from the data array
    setData(data.filter((item) => item.incidentid !== id));
  };


  return (
    <div>
      <h5>
        Incidents
      </h5>
      <br></br>
      <h6 class = "btn2">
      <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => newIncident()}>Report New Incident</button>
      </h6>
      <br></br>
      <table>
        <tr>
          <th><b>Name</b></th>
          <th><b>Type</b></th>
          <th><b>Reported by</b></th>
          <th><b>Contact</b></th>
          <th><b>Date</b></th>
          <th><b>Status</b></th>
          <th></th>
        </tr>
        
        {data.map(item => (   // display description in the details that pop up when you click
          <tr key={item.incidentid}>
          <td>{item.incidentname}</td>
          <td>{item.inc_type}</td>
          <td>{item.reportername}</td>
          <td>{item.reporterphone}</td>
          <td>{item.datereported}</td>
          <td>{item.incidentstatus}</td>
          <td>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => incidentDetails(item.incidentid)}>Details</button>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => editFunction(item.incidentid)}>Edit</button>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => deleteRow(item.incidentid)}>Delete</button></td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default ShowIncidents;
