package com.javatpoint.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.javatpoint.model.Payments;
import com.javatpoint.service.PaymentsService;
//mark class as Controller

@RestController
public class PaymentsController 
{
    //autowire the BooksService class
    @Autowired
    PaymentsService paymentsService;
    
    //creating a get mapping that retrieves all the books detail from the database 
    @GetMapping("/payment")
    private List<Payments> getAllPayments() 
    {
        return paymentsService.getAllPayments();
    }

    //creating a get mapping that retrieves the detail of a specific book
    @GetMapping("/payment/{paymentid}")
    private Payments getPayments(@PathVariable("paymentid") int paymentid) 
    {
        return paymentsService.getPaymentsById(paymentid);
    }

    //creating a delete mapping that deletes a specified book
    @DeleteMapping("/payment/{paymentid}")
    private void deletePayment(@PathVariable("paymentid") int paymentid) 
    {
        paymentsService.delete(paymentid);
    }

    //creating post mapping that post the book detail in the database
    @PostMapping("/payments")
    private int savePayment(@RequestBody Payments payments) 
    {
        paymentsService.saveOrUpdate(payments);
        return payments.getpaymentid();
    }

    //creating put mapping that updates the book detail 
    @PutMapping("/payments")
    private Payments update(@RequestBody Payments payments) 
    {
        paymentsService.saveOrUpdate(payments);
        return payments;
    }
}
