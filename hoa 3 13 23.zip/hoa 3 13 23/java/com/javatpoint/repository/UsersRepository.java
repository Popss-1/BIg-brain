package com.javatpoint.repository;
//import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
//repository that extends CrudRepository
import com.javatpoint.model.Users;

public interface UsersRepository extends CrudRepository<Users, Integer>
{
    
}
