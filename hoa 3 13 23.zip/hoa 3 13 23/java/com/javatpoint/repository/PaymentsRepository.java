package com.javatpoint.repository;
import org.springframework.data.repository.CrudRepository;
//repository that extends CrudRepository
import com.javatpoint.model.Payments;

public interface PaymentsRepository extends CrudRepository<Payments, Integer>
{
    
}
