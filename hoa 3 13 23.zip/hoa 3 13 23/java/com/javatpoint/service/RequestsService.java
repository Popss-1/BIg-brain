package com.javatpoint.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.javatpoint.model.Requests;
import com.javatpoint.repository.RequestsRepository;
//defining the business logic
@Service
public class RequestsService 
{

@Autowired
RequestsRepository requestsRepository;
//getting all incidents record by using the method findaAll() of CrudRepository
public List<Requests> getAllRequests() 
{
    List<Requests> requests = new ArrayList<Requests>();
    requestsRepository.findAll().forEach(requests1 -> requests.add(requests1));
    return requests;
}

//getting a specific record by using the method findById() of CrudRepository
public Requests getRequestsById(int id) 
{
    return requestsRepository.findById(id).get();
}

//saving a specific record by using the method save() of CrudRepository
public void saveOrUpdate(Requests requests) 
{
    requestsRepository.save(requests);
}

//deleting a specific record by using the method deleteById() of CrudRepository
public void delete(int id) 
{
    requestsRepository.deleteById(id);
}

//updating a record
public void update(Requests requests, int requestid) 
{
    requestsRepository.save(requests);
}
}