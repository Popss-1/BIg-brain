package com.javatpoint.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.javatpoint.model.Payments;
import com.javatpoint.repository.PaymentsRepository;
//defining the business logic
@Service
public class PaymentsService 
{

@Autowired
PaymentsRepository paymentsRepository;
//getting all incidents record by using the method findaAll() of CrudRepository
public List<Payments> getAllPayments() 
{
    List<Payments> payments = new ArrayList<Payments>();
    paymentsRepository.findAll().forEach(payments1 -> payments.add(payments1));
    return payments;
}

//getting a specific record by using the method findById() of CrudRepository
public Payments getPaymentsById(int id) 
{
    return paymentsRepository.findById(id).get();
}

//saving a specific record by using the method save() of CrudRepository
public void saveOrUpdate(Payments payments) 
{
    paymentsRepository.save(payments);
}

//deleting a specific record by using the method deleteById() of CrudRepository
public void delete(int id) 
{
    paymentsRepository.deleteById(id);
}

//updating a record
public void update(Payments payments, int paymentid) 
{
    paymentsRepository.save(payments);
}
}