package com.javatpoint.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//mark class as an Entity 
@Entity
//defining class name as Table name
@Table
public class Payments
{
    //Defining book id as primary key
    @Id
    @Column
    private int paymentid;
    @Column
    private String paymentname;
    @Column
    private String duedate;
    @Column
    private Double amountowed;
    @Column
    private Boolean ispaid;
    @Column
    private String owedbyfname;
    @Column
    private String owedbylname;
    @Column
    private String owedbyphone;
    @Column
    private String owedbyemail;

    
    public int getpaymentid() 
    {
        return paymentid;
    }

    public void setpaymentid(int paymentid) 
    {
        this.paymentid = paymentid;
    }

    public String getpaymentname()
    {
        return paymentname;
    }

    public void setpaymentname(String paymentname) 
    {
        this.paymentname = paymentname;
    }

    public String getduedate()
    {
        return duedate;
    }

    public void setduedate(String duedate) 
    {
        this.duedate = duedate;
    }

    public Double getamountowed()
    {
        return amountowed;
    }

    public void setamountowed(Double amountowed) 
    {
        this.amountowed = amountowed;
    }

    public Boolean getispaid() 
    {
        return ispaid;
    }

    public void setispaid(Boolean ispaid) 
    {
        this.ispaid = ispaid;
    }

    public String getowedbyfname() 
    {
        return owedbyfname;
    }

    public void setowedbyfname(String owedbyfname) 
    {
        this.owedbyfname = owedbyfname;
    }

    public String getowedbylname() 
    {
        return owedbylname;
    }

    public void setowedbylname(String owedbylname) 
    {
        this.owedbylname = owedbylname;
    }

    public String getowedbyphone() 
    {
        return owedbyphone;
    }

    public void setowedbyphone(String owedbyphone) 
    {
        this.owedbyphone = owedbyphone;
    }

    public String getowedbyemail() 
    {
        return owedbyemail;
    }

    public void setowedbyemail(String owedbyemail) 
    {
        this.owedbyemail = owedbyemail;
    }

    
}