package com.javatpoint.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//mark class as an Entity 
@Entity
//defining class name as Table name
@Table
public class Users
{
    //Defining book id as primary key
    @Id
    @Column
    private int userid;
    @Column
    private String username;
    @Column
    private String firstname;
    @Column
    private String lastname;
    @Column
    private String userphone;
    @Column
    private String useremail;
    @Column
    private String useraddress;
    @Column
    private String userstatus;
    @Column
    private String usertype;

    // !!! got to do a lot of input validation type checks and some columns should appear in multiple tables, do foreign keys and whatnot
    
    public int getuserid() 
    {
        return userid;
    }

    public void setuserid(int userid) 
    {
        this.userid = userid;
    }

    public String getusername() 
    {
        return username;
    }

    public void setusername(String username) 
    {
        this.username = username;
    }

    public String getfirstname() 
    {
        return firstname;
    }

    public void setfirstname(String firstname) 
    {
        this.firstname = firstname;
    }

    public String getlastname() 
    {
        return lastname;
    }

    public void setlastname(String lastname) 
    {
        this.lastname = lastname;
    }

    public String getuserphone() 
    {
        return userphone;
    }

    public void setuserphone(String userphone) 
    {
        this.userphone = userphone;
    }

    public String getuseremail() 
    {
        return useremail;
    }

    public void setuseremail(String useremail) 
    {
        this.useremail = useremail;
    }

    public String getuseraddress() 
    {
        return useraddress;
    }

    public void setuseraddress(String useraddress) 
    {
        this.useraddress = useraddress;
    }

    public String getuserstatus() 
    {
        return userstatus;
    }

    public void setuserstatus(String userstatus) 
    {
        this.userstatus = userstatus;
    }

    public String getusertype() 
    {
        return usertype;
    }

    public void setusertype(String usertype) 
    {
        this.usertype = usertype;
    }
}