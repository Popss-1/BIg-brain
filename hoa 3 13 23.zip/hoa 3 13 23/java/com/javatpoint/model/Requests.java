package com.javatpoint.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//mark class as an Entity 
@Entity
//defining class name as Table name
@Table
public class Requests
{
    //Defining book id as primary key
    @Id
    @Column
    private int requestid;
    @Column
    private String reqtype;
    @Column
    private String reqlocation;
    @Column
    private String reqdescription;
    @Column
    private String reqfname;
    @Column
    private String reqlname;
    @Column
    private String reqphone;
    @Column
    private String reqemail;
    @Column
    private String reqstatus;
    @Column
    private String reqdate;

    
    public int getrequestid() 
    {
        return requestid;
    }

    public void setrequestid(int requestid) 
    {
        this.requestid = requestid;
    }

    public String getreqtype()
    {
        return reqtype;
    }

    public void setreqtype(String reqtype) 
    {
        this.reqtype = reqtype;
    }

    public String getreqlocation()
    {
        return reqlocation;
    }

    public void setreqlocation(String reqlocation) 
    {
        this.reqlocation = reqlocation;
    }

    public String getreqdescription() 
    {
        return reqdescription;
    }

    public void setreqdescription(String reqdescription) 
    {
        this.reqdescription = reqdescription;
    }

    public String getreqfname() 
    {
        return reqfname;
    }

    public void setreqfname(String reqfname) 
    {
        this.reqfname = reqfname;
    }

    public String getreqlname() 
    {
        return reqlname;
    }

    public void setreqlname(String reqlname) 
    {
        this.reqlname = reqlname;
    }

    public String getreqphone() 
    {
        return reqphone;
    }

    public void setreqphone(String reqphone) 
    {
        this.reqphone = reqphone;
    }

    public String getreqemail() 
    {
        return reqemail;
    }

    public void setreqemail(String reqemail) 
    {
        this.reqemail = reqemail;
    }

    public String getreqstatus() 
    {
        return reqstatus;
    }

    public void setreqstatus(String reqstatus) 
    {
        this.reqstatus = reqstatus;
    }

    public String getreqdate() 
    {
        return reqdate;
    }

    public void setreqdate(String reqdate) 
    {
        this.reqdate = reqdate;
    }
}