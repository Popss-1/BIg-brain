import logo from './logo.svg';
import './App.css';
import React, { Component , useState, useEffect } from "react";
import {Current_Incident, cur_incident} from './incidentclass.js';
//import NewIncident from './newincident.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';
import MapContainer from './mapcontainer';


class IncidentMap extends React.Component {

  constructor(props) {
    super(props);
  };

  render() {
    return (
      <div className="App">
        <br>
        </br>
        <h2 class = "mapheader">Incidents are displayed as red markers - click to view details.</h2>
        <h2 class = "mapheader2"><b>Double Click on the map to report an incident there!</b></h2>
        <MapContainer
          google={window.google} changeRState = {this.props.changeRState} changelatlong = {this.props.changelatlong}
        />

        </div>
    );
  }
}

export default IncidentMap;