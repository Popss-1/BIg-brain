import React, { Component } from "react";

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

import App from './App';

export class Current_Payment {
  
  constructor(val_init)  {
    
    this.state = {
      current: val_init,
      prev: 0
    };

    this.setCurrentPayment = this.setCurrentPayment.bind(this);
  
  }

  setCurrentPayment(user_indx) {
   this.state = {
    current: user_indx
   }
  };

  //edit, details, delete

}

export const cur_payment = new Current_Payment(0);