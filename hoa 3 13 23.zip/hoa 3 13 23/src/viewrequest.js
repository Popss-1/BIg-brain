import logo from './logo.svg';
import './App.css';
import React, { Component , useState, useEffect } from "react";
import {Current_Request, cur_request} from './requestclass.js';
//import NewIncident from './newincident.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class DetailsRequest extends Component {

  constructor(props)  {
    super(props)

  };

  render()  
  {

    return (
      < DisplayRow changeRState = {this.props.changeRState} />
    );
  }

}

const DisplayRow = props => {
  
  const [data, setData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await fetch(`http://localhost:8090/request/${cur_request.state.current}`);
      const data = await response.json();
      setData(data);
    }
    fetchData();
  }, []);


  const editFunction = (id) =>  { 
    cur_request.setCurrentRequest(id);
    console.log("edit button clicked " + id);
    props.changeRState(14);
 
  };
  

  return (
      <><p>
      <h5 class="details">
        Request Type: {data.reqtype}
      </h5>
      <h4 class="details">
        Location: {data.reqlocation}
      </h4>
      <h4 class="details">
        Description: {data.reqdescription}
      </h4>
      <br></br>
      <h4>
      <table class="details">
        <tr>
          <th><b>First Name</b></th>
          <th><b>Last Name</b></th>
          <th><b>Phone</b></th>
          <th><b>Email</b></th>
          <th><b>Date</b></th>
          <th><b>Status</b></th>
        </tr>
        <tr>
          <td>{data.reqfname}</td>
          <td>{data.reqlname}</td>
          <td>{data.reqphone}</td>
          <td>{data.reqemail}</td>
          <td>{data.reqdate}</td>
          <td>{data.reqstatus}</td>
        </tr>
      </table>
      </h4>
      <br></br>
      <h6 class = "btn2">
      <button class="linkCssinner2" title="hyperlink button" type="submit" onClick = {() => editFunction(data.requestid)}>Edit Request</button>
      </h6>
      </p>
      <h3 class="incidentdetails">
        &copy; 2023 by Group 5
      </h3></>
  );
  
}


export default DetailsRequest;
