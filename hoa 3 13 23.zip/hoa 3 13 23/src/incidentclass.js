import React, { Component } from "react";

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

import App from './App';

export class Current_Incident {
  
  constructor(val_init)  {
    
    this.state = {
      current: val_init,
      prev: 0
    };

    this.setCurrentIncident = this.setCurrentIncident.bind(this);

  
  }

  setCurrentIncident(incident_indx) {
   this.state = {
    current: incident_indx
   }
  };

  //edit, details, delete

}

export const cur_incident = new Current_Incident(-1);