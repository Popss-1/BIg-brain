import logo from './logo.svg';
import './App.css';
import React, { Component , useState, useEffect } from "react";
import {Current_User, cur_user} from './userclass.js';
//import NewIncident from './newincident.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class ShowUsers extends Component {

  constructor(props)  {
    super(props)

  };

  /*
  async componentDidMount() {
    const response = await fetch('localhost:8090/incident');
    //const body = await response.json();
    this.setState({});//users: body});
  }*/

  render()  
  {

  return (
    < DisplayRows changeRState = {this.props.changeRState} />
  );
  }

}

const DisplayRows = props => {

  const [data, setData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await fetch('http://localhost:8090/user');
      const data = await response.json();
      setData(data);
    }
    fetchData();
  }, []);


  const newUser = () =>  {
    console.log('new user');
    props.changeRState(13);

  };

  const userDetails = (id) =>  {
    cur_user.setCurrentUser(id);
    console.log("details button clicked " + id);
    props.changeRState(12);

  };


  const editFunction = (id) =>  { 
   cur_user.setCurrentUser(id);
   console.log("edit button clicked " + id);
   props.changeRState(11);

  };

  const deleteRow = async (id) => {
    // make an API call to delete the row
    await fetch(`http://localhost:8090/user/${id}`, {
      method: 'DELETE',
    });

    // remove the deleted row from the data array
    setData(data.filter((item) => item.userid !== id));
  };


  return (
    <div>
      <h5>
        Users
      </h5>
      <br></br>
      <h6 class = "btn2">
      <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => newUser()}>Add New User</button>
      </h6>
      <br></br>
      <table>
        <tr>
          <th><b>Username</b></th>
          <th><b>First Name</b></th>
          <th><b>Last Name</b></th>
          <th><b>Phone</b></th>
          <th><b>Email</b></th>
          <th><b>Status</b></th>
          <th></th>
        </tr>
        
        {data.map(item => (   // display description in the details that pop up when you click
          <tr key={item.userid}>
          <td>{item.username}</td>
          <td>{item.firstname}</td>
          <td>{item.lastname}</td>
          <td>{item.userphone}</td>
          <td>{item.useremail}</td>
          <td>{item.userstatus}</td>
          <td>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => userDetails(item.userid)}>Details</button>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => editFunction(item.userid)}>Edit</button>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => deleteRow(item.userid)}>Delete</button></td>
          </tr>
        ))}
      </table>

      <h3 class="incidentpage">
        &copy; 2023 by Group 5
      </h3>
    </div>
  );
}

export default ShowUsers;
