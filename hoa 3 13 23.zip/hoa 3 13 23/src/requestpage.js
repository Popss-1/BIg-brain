import logo from './logo.svg';
import './App.css';
import React, { Component , useState, useEffect } from "react";
import {Current_Request, cur_request} from './requestclass.js';
//import NewIncident from './newincident.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class ShowRequests extends Component {

  constructor(props)  {
    super(props)

  };

  /*
  async componentDidMount() {
    const response = await fetch('localhost:8090/incident');
    //const body = await response.json();
    this.setState({});//users: body});
  }*/

  render()  
  {

  return (
    < DisplayRows changeRState = {this.props.changeRState} />
  );
  }

}

const DisplayRows = props => {

  const [data, setData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await fetch('http://localhost:8090/request');
      const data = await response.json();
      setData(data);
    }
    fetchData();
  }, []);


  const newRequest = () =>  {
    console.log('new request');
    props.changeRState(16);

  };

  const requestDetails = (id) =>  {
    cur_request.setCurrentRequest(id);
    console.log("details button clicked " + id);
    props.changeRState(15);

  };


  const editFunction = (id) =>  { 
   cur_request.setCurrentRequest(id);
   console.log("edit button clicked " + id);
   props.changeRState(14);

  };

  const deleteRow = async (id) => {
    // make an API call to delete the row
    await fetch(`http://localhost:8090/request/${id}`, {
      method: 'DELETE',
    });

    // remove the deleted row from the data array
    setData(data.filter((item) => item.requestid !== id));
  };


  return (
    <div>
      <h5>
        Maintenance Requests
      </h5>
      <br></br>
      <h6 class = "btn2">
      <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => newRequest()}>Make Request</button>
      </h6>
      <br></br>
      <table>
        <tr>
          <th><b>Request Type</b></th>
          <th><b>Date</b></th>
          <th><b>First Name</b></th>
          <th><b>Last Name</b></th>
          <th><b>Phone</b></th>
          <th><b>Email</b></th>
          <th></th>
        </tr>

        {data.map(item => (   // display description in the details that pop up when you click
          <tr key={item.requestid}>
          <td>{item.reqtype}</td>
          <td>{item.reqdate}</td>
          <td>{item.reqfname}</td>
          <td>{item.reqlname}</td>
          <td>{item.reqphone}</td>
          <td>{item.reqemail}</td>
          <td>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => requestDetails(item.requestid)}>Details</button>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => editFunction(item.requestid)}>Edit</button>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => deleteRow(item.requestid)}>Delete</button></td>
          </tr>
        ))}
      </table>

      <h3 class="incidentpage">
        &copy; 2023 by Group 5
      </h3>
    </div>
  );
}

export default ShowRequests;
