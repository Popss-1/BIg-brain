import React, { Component } from "react";

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

import App from './App';

export class Current_User {
  
  constructor(val_init)  {
    
    this.state = {
      current: val_init,
      prev: 0
    };

    this.setCurrentUser = this.setCurrentUser.bind(this);
  
  }

  setCurrentUser(user_indx) {
   this.state = {
    current: user_indx
   }
  };

  //edit, details, delete

}

export const cur_user = new Current_User(0);