import logo from './logo.svg';
import './App.css';
import React, { Component , useState, useEffect } from "react";
import {Current_Payment, cur_payment} from './paymentclass.js';
//import NewIncident from './newincident.js';
import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class ShowPayments extends Component {

  constructor(props)  {
    super(props)

  };

  /*
  async componentDidMount() {
    const response = await fetch('localhost:8090/incident');
    //const body = await response.json();
    this.setState({});//users: body});
  }*/

  render()  
  {

  return (
    < DisplayRows changeRState = {this.props.changeRState} />
  );
  }

}

const DisplayRows = props => {

  const [data, setData] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await fetch('http://localhost:8090/payment');
      const data = await response.json();
      setData(data);
    }
    fetchData();
  }, []);


  const newPayment = () =>  {
    console.log('new payment');
    props.changeRState(19);

  };

  const paymentDetails = (id) =>  {
    cur_payment.setCurrentPayment(id);
    console.log("details button clicked " + id);
    props.changeRState(18);

  };


  const editFunction = (id) =>  { 
    cur_payment.setCurrentPayment(id);
   console.log("edit button clicked " + id);
   props.changeRState(17);

  };

  const deleteRow = async (id) => {
    // make an API call to delete the row
    await fetch(`http://localhost:8090/payment/${id}`, {
      method: 'DELETE',
    });

    // remove the deleted row from the data array
    setData(data.filter((item) => item.paymentid !== id));
  };


  return (
    <div>
      <h5>
        Payments
      </h5>
      <br></br>
      <h6 class = "btn2">
      <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => newPayment()}>Add New Payment</button>
      </h6>
      <br></br>
      <table>
        <tr>
          <th><b>Payment</b></th>
          <th><b>Amount</b></th>
          <th><b>Due Date</b></th>
          <th><b>Paid</b></th>
          <th><b>First Name</b></th>
          <th><b>Last Name</b></th>
          <th></th>
        </tr>
        
        {data.map(item => (   // display description in the details that pop up when you click
          <tr key={item.paymentid}>
          <td>{item.paymentname}</td>
          <td>{item.amountowed}</td>
          <td>{item.duedate}</td>
          <td>{item.ispaid}</td>
          <td>{item.owedbyfname}</td>
          <td>{item.owedbylname}</td>
          <td>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => paymentDetails(item.paymentid)}>Details</button>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => editFunction(item.paymentid)}>Edit</button>
            <button class="linkCsstable" title="hyperlink button" type="submit" onClick = {() => deleteRow(item.paymentid)}>Delete</button></td>
          </tr>
        ))}
      </table>

      <h3 class="incidentpage">
        &copy; 2023 by Group 5
      </h3>
    </div>
  );
}

export default ShowPayments;
