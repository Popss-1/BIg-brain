import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";
import {Current_User, cur_user} from './userclass.js';

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

class EditUser extends Component {

  constructor(props) {
    super(props);

    this.state = {
      data: [],
      userid: "",
      username: "",
      firstname: "",
      lastname: "",
      userphone: "",
      useremail: "",
      useraddress: "",
      userstatus: "",
      usertype: "",
      loading: false,
      error: null
    };

  };


  componentDidMount() {
    this.setState({ loading: true });

    console.log("userid is: " + cur_user.state.current);

    fetch(`http://localhost:8090/user/${cur_user.state.current}`)
      .then(response => response.json())
      .then(data => this.setState({ data, userid: data.userid, username: data.username, firstname: data.firstname, 
        lastname: data.lastname, userphone: data.userphone, useremail: data.useremail, useraddress: data.useraddress,
        userstatus: data.userstatus, usertype: data.usertype }))
      .catch(error => this.setState({ error, loading: false }));
  }

  handleChange_username = (event) =>
  {
    this.setState({username: event.target.value});

  };

  handleChange_firstname = (event) =>
  {
    this.setState({firstname: event.target.value});

  };
  
  handleChange_lastname = (event) =>
  {
    this.setState({lastname: event.target.value});

  };

  handleChange_userphone = (event) =>
  {
    this.setState({userphone: event.target.value});

  };

  handleChange_useremail = (event) =>
  {
    this.setState({useremail: event.target.value});

  };

  handleChange_useraddress = (event) =>
  {
    this.setState({useraddress: event.target.value});

  };

  handleChange_userstatus = (event) =>
  {
    this.setState({userstatus: event.target.value});

  };

  handleChange_usertype = (event) =>
  {
    this.setState({usertype: event.target.value});

  };


  changeSelected = () =>  
  {

    fetch('http://localhost:8090/users', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userid: this.state.userid,
      username: this.state.username,
      firstname: this.state.firstname,
      lastname: this.state.lastname,
      userphone: this.state.userphone,
      useremail: this.state.useremail,
      useraddress: this.state.useraddress,
      userstatus: this.state.userstatus,
      usertype: this.state.usertype,
    })
  })
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error(error));

  };


  handleChange = () =>  
  {

    this.changeSelected();

    this.props.changeRState(2);
  
  }

  render()  
  {

  const { data, loading, error } = this.state;


  return (
    <><p>
    <h5>
    Edit User
    </h5>
    </p>
    <br></br>
    <h6>
    <form>
    
    <label>Username:
      <input type = "text" id = "name" value = {this.state.username} onChange = {this.handleChange_username} />
    </label>
    <br></br><br></br>
    <label>First Name: 
      <input type = "text1" id = "fname" value = {this.state.firstname} onChange = {this.handleChange_firstname} />
    </label>
    <br></br><br></br>
    <label>Last Name: 
      <input type = "text2" id = "lname" value = {this.state.lastname} onChange = {this.handleChange_lastname} />
    </label>
    <br></br><br></br>
    <label>Phone Number: 
      <input type = "text3" id = "uphone" value = {this.state.userphone} onChange = {this.handleChange_userphone} />
    </label>
    <br></br><br></br>
    <label>Email: 
      <input type = "text4" id = "uemail" value = {this.state.useremail} onChange = {this.handleChange_useremail} />
    </label>
    <br></br><br></br>
    <label>Address:
      <input type = "text5" id = "uaddr" value = {this.state.useraddress} onChange = {this.handleChange_useraddress} />
    </label>
    <br></br><br></br>
    <label>Status: 
      <input type = "text6" id = "ustatus" value = {this.state.userstatus} onChange = {this.handleChange_userstatus} />
    </label>
    <br></br><br></br>
    <label>User Type: 
      <input type = "text7" id = "utype" value = {this.state.usertype} onChange = {this.handleChange_usertype} />
    </label>

    </form>
    </h6>

    <p>
    <h6 class = "btn">
    <button class="linkCssinner" title="hyperlink button" type="submit" onClick = {() => this.handleChange()}>Save and Exit</button>
    <br></br>
    <br></br>
    </h6>
    </p>
    
    
    <h3>
    &copy; 2023 by Group 5
    </h3></>

  );
  }

}

export default EditUser;
