import logo from './logo.svg';
import './App.css';
import React, { Component } from "react";




class MainPage extends Component {

    render()  
    {
  
    return (
        <div>
        <p>
        
        <img src="picturehouses4.JPG" alt="picture suburban" height="466" width="1024"></img>
        
        <h4>
        Welcome <Bold>nguyenhien123</Bold>!
        <br></br>
        <br></br>
        This is a webapp that helps the community stay connected by reporting incidents and streamlining the communication process.
        </h4>
        
        </p>

        <h3>
        &copy; 2023 by Group 5
        </h3>
        </div>
    );
    }
  
  }

export default TemporaryComponent;