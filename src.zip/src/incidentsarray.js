import React, { Component } from "react";

import RoutingStates from './routingstates.js';
import {state_switcher} from './routingstates.js';

import App from './App';

export var cur_incident = 0;

class Incident {
  constructor(description, name, phone, email, date, location, status, type)  {
    
    this.state = {
      desc: description,
      full_name: name,
      phone_number: phone,
      personal_email: email,
      date_current: date,
      loc: location,
      status_type: status,
      type_inc: type
    };

    this.setCurrentIncident = this.setCurrentIncident.bind(this);

    this.setIncidentStates = this.setIncidentStates.bind(this);
  
  }

  setCurrentIncident(incident_indx) {
   cur_incident = incident_indx;

   console.log({cur_incident});
  };

  setIncidentStates(inc_type, pnum, email, date, location, description, name, status)  {
    this.state = {
      type_inc: inc_type,
      phone_number: pnum,
      personal_email: email,
      date_current: date,
      loc: location,
      desc: description,
      full_name: name,
      status_type: status
    };

  };

  //edit, details, delete

}

export const incidents = new Array();

let incident1 = new Incident("Intruder", "Fred", "717-321-0987", "fredflinstone@gmail.com", "12/13/2021",
  "12 Ergl Lane", "Closed", "Intruder");

let incident2 = new Incident("Defaced sign", "Betty", "717-123-7890", "bettyflinstone@email.com", 
 "12/15/2021", "12 Ergl Lane", "Closed", "Vandalism");

incidents.push(incident1);
incidents.push(incident2);

export default Incident